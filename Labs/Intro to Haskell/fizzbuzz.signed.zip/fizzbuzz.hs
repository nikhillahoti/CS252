-- Do the game fizzbuzz (http://en.wikipedia.org/wiki/Fizz_buzz).
-- Return a string counting from 1 to the specified number.
-- Replace numbers dvisible by 3 with "fizz" and numbers divisible
-- by 5 with "buzz".  If a number is divisible by both 3 and 5,
-- replace it with "fizzbuzz".

fizzbuzz :: Int -> String
checkFizzBuzz a 
 | a `mod` 15 == 0 = "fizzbuzz" 
 | a `mod` 3 == 0 = "fizz" 
 | a `mod` 5 == 0 = "buzz" 
 | otherwise = show a

fizzbuzz a
 | a > 0 = fizzbuzz (a-1) ++ " " ++ checkFizzBuzz a
 | otherwise = ""

main :: IO ()
main = do
  print (fizzbuzz 1)
  print (fizzbuzz 7)
  print $ fizzbuzz 99
  print $ fizzbuzz 0
  print $ fizzbuzz (-2)