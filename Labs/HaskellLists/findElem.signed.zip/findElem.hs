-- Return the item at the specified position
findKthElem :: Ord a => Int -> [a] -> a
findKthElem _ [] = error " Empty List"
findKthElem n x
 | n < 0 = error " Cannnot have negative numbered list."
 | n > (length x) || n < 0 = error " Not enough elements in the list "
 | otherwise = last (take (n+1) x)




main :: IO ()
main = do
  print $ findKthElem 0 [1..99]
  print $ findKthElem 50 [1..99]
  print $ findKthElem 3 ["apple", "banana", "cherry", "durian", "", "fig"]
  print $ findKthElem 50 [1..9]
  -- Last test case won't run, but you should consider it
  print $ findKthElem (-1) [1..9]