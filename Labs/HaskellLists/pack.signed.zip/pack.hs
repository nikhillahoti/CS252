-- Pack consecutive duplicates of list elements into sublists
pack :: Eq a => [a] -> [[a]]


findEqual _ [] = []
findEqual a (x:xs)
 | a == x = x: findEqual a xs
 | otherwise = []

findNotEqual _ [] = []
findNotEqual a (x:xs)
 | a == x = findNotEqual a xs
 | otherwise = (x:xs)

pack [] = []
pack [x] = [[x]]
pack x 
 | length (findNotEqual (head x) x) > 0 = findEqual (head x) x : pack (findNotEqual (head x) x)
 | otherwise = [findEqual (head x) x]


main :: IO ()
main = do
  print $ pack "aaaaaabbbbbbbbccccccccddddddd"
  print $ pack ""
  print $ pack [1,1,2,3,99,2,-1,42,42,42,42]