
isPalindrome :: String -> Bool

isPalindrome [] = True
isPalindrome [x] = True
isPalindrome (x:xs)
 | x == (last xs) && isPalindrome (take (length xs - 1) xs) = True
 | otherwise = False


main :: IO ()
main = do
  print $ isPalindrome ""
  print $ isPalindrome "a"
  print $ isPalindrome "Y"
  print $ isPalindrome "aa"
  print $ isPalindrome "ab"
  print $ isPalindrome "aba"
  print $ isPalindrome "cab"
  print $ isPalindrome "abba"
  print $ isPalindrome "beet"
  print $ isPalindrome "barb"
  print $ isPalindrome "racecar"
  print $ isPalindrome "race car"